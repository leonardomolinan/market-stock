package Estoque;
import java.util.Scanner;
import view.TelaListar;
import java.io.Serializable;

public class Alimenticio extends Produto implements naoDuravel, Serializable {
    private String dataValidade;

    @Override
    public String getDataValidade() {
    return dataValidade;
    }
    
    public void setDataValidade(String dataValidade) {
        this.dataValidade = dataValidade;
    }
    

    
}


