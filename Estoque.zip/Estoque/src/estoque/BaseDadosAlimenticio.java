package Estoque;
import java.util.*;
import persistencia.*;
public class BaseDadosAlimenticio {
    private static ArrayList<Alimenticio> alimentos;
    
    static{
        alimentos = (ArrayList<Alimenticio>)Persist.recuperar("Alimenticio.dat");
        if(alimentos == null) alimentos = new ArrayList<Alimenticio>();
    }
    
    public static void adicionar(Alimenticio a){
        alimentos.add(a);
        boolean r = Persist.gravar(alimentos, "Alimenticio.dat");
    }
   

    public static ArrayList<Alimenticio> listar(){
        return alimentos;
    }

    public static Alimenticio buscar(int codigo){
        for (Alimenticio a: alimentos){
            if (a.getCodigo()==codigo){
                return a;
            }
        }
        return null;
    }

    public static boolean excluir(int codigo){
        for (Alimenticio a: alimentos){
            if (a.getCodigo()==codigo){
                alimentos.remove(a);
                boolean r = Persist.gravar(alimentos, "Alimenticio.dat");
                return true;
            }
        }
        return false;
    }
}
