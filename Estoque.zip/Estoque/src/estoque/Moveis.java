package Estoque;
import java.io.Serializable;

public class Moveis extends Produto implements Serializable{
    private String material;

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
   
    public int getCodigo(){
        return super.getCodigo();
    }
}
