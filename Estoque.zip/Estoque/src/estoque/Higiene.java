package Estoque;
import java.io.Serializable;

public class Higiene extends Produto implements naoDuravel, Serializable{
    private String dataValidade;

    public String getDataValidade() {
        return this.dataValidade;
    }

    public void setDataValidade(String dataValidade) {
        this.dataValidade = dataValidade;
    }
    
    public int getCodigo(){
        return super.getCodigo();
    }

}
