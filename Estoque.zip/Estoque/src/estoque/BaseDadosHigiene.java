package Estoque;
import java.util.*;
import persistencia.Persist;
public class BaseDadosHigiene {
    private static ArrayList<Higiene> higiene;
    static{
        higiene = (ArrayList<Higiene>)Persist.recuperar("Higiene.dat");
        if(higiene == null) higiene = new ArrayList<Higiene>();
    }
    
    public static void adicionar(Higiene h){
        higiene.add(h);
        Persist.gravar(higiene, "Higiene.dat");
    }

    public static ArrayList<Higiene> listar(){
        return higiene;
    }

    public static Higiene buscar(int codigo){
        for (Higiene h: higiene){
            if (h.getCodigo()==codigo){
                return h;
            }
        }
        return null;
    }

    public static boolean excluir(int codigo){
        for (Higiene h: higiene){
            if (h.getCodigo()==codigo){
                higiene.remove(h);
                Persist.gravar(higiene, "Higiene.dat");
                return true;
            }
        }
        return false;
    }
}
