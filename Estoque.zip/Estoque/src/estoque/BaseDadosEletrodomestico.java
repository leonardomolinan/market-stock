package Estoque;
import java.util.*;
import persistencia.Persist;
public class BaseDadosEletrodomestico {
    private static ArrayList<Eletrodomesticos> eletrodomesticos;
    
    static{
        eletrodomesticos = (ArrayList<Eletrodomesticos>)Persist.recuperar("Eletrodomesticos.dat");
        if(eletrodomesticos == null) eletrodomesticos = new ArrayList<Eletrodomesticos>();
    }
    
    public static void adicionar(Eletrodomesticos e){
        eletrodomesticos.add(e);
        Persist.gravar(eletrodomesticos, "Eletrodomesticos.dat");
    }

    public static ArrayList<Eletrodomesticos> listar(){
       return eletrodomesticos;
    }

    public static Eletrodomesticos buscar(int codigo){
        for (Eletrodomesticos e: eletrodomesticos){
            if (e.getCodigo()==codigo){
                return e;
            }
        }
        return null;
    }

    public static boolean excluir(int codigo){
        for (Eletrodomesticos e: eletrodomesticos){
            if (e.getCodigo()==codigo){
                eletrodomesticos.remove(e);
                Persist.gravar(eletrodomesticos, "Eletrodomesticos.dat");
                return true;
            }
        }
        return false;
    }
}
