package Estoque;
import java.io.Serializable;

public class Eletrodomesticos extends Produto implements Serializable{
    private String voltagem;

    public String getVoltagem() {
        return voltagem;
    }

    public void setVoltagem(String voltagem) {
        this.voltagem = voltagem;
    }

    public int getCodigo(){
        return super.getCodigo();
    }

}
