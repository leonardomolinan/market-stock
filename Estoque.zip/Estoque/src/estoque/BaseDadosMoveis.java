package Estoque;
import java.util.*;
import persistencia.Persist;
public class BaseDadosMoveis {
    private static ArrayList<Moveis> moveis;
    
    static{
        moveis = (ArrayList<Moveis>)Persist.recuperar("Moveis.dat");
        if(moveis == null) moveis = new ArrayList<Moveis>();
    }
    
    public static void adicionar(Moveis m){
        moveis.add(m);
        Persist.gravar(moveis, "Moveis.dat");
    }

    public static ArrayList<Moveis> listar(){
        return moveis;
    }

    public static Moveis buscar(int codigo){
        for (Moveis m: moveis){
            if (m.getCodigo()==codigo){
                return m;
            }
        }
        return null;
    }

    public static boolean excluir(int codigo){
        for (Moveis m: moveis){
            if (m.getCodigo()==codigo){
                moveis.remove(m);
                Persist.gravar(moveis, "Moveis.dat");
                return true;
            }
        }
        return false;
    }
}
