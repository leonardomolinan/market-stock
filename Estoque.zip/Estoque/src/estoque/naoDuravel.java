
package Estoque;

interface naoDuravel {
    public String getDataValidade();
    public void setDataValidade(String dataValidade);
}
