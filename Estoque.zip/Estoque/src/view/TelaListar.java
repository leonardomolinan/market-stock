package view;

import java.util.ArrayList;
import Estoque.Alimenticio;
import Estoque.BaseDadosAlimenticio;
import Estoque.BaseDadosEletrodomestico;
import Estoque.BaseDadosHigiene;
import Estoque.BaseDadosMoveis;
import Estoque.Eletrodomesticos;
import Estoque.Higiene;
import Estoque.Moveis;
import javax.swing.JOptionPane;


public class TelaListar extends javax.swing.JInternalFrame {
    /**
     * Creates new form TelaListar
     */
    public TelaListar() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jbListar = new javax.swing.JButton();
        jbvoltarL = new javax.swing.JButton();

        setClosable(true);
        setMaximizable(true);
        setTitle("Listar");
        setMinimumSize(new java.awt.Dimension(577, 528));
        setPreferredSize(new java.awt.Dimension(577, 528));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setText("Listar");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Selecione o tipo:");

        jComboBox1.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Alimenticio", "Eletrodomestico", "Higiene", "Moveis" }));
        jComboBox1.setSelectedIndex(-1);
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jbListar.setText("Listar");
        jbListar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jbListarMouseReleased(evt);
            }
        });
        jbListar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbListarActionPerformed(evt);
            }
        });

        jbvoltarL.setText("Voltar");
        jbvoltarL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbvoltarLActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jbListar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 13, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(37, 37, 37))
            .addGroup(layout.createSequentialGroup()
                .addGap(236, 236, 236)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jbvoltarL)
                .addGap(55, 55, 55))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbListar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jbvoltarL)
                .addGap(14, 14, 14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbvoltarLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbvoltarLActionPerformed
        dispose();
    }//GEN-LAST:event_jbvoltarLActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jbListarMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jbListarMouseReleased
        try{
        int tipo = jComboBox1.getSelectedIndex();
        jTextArea1.setText("");
        switch (tipo){ 
        case 0:
            ArrayList<Alimenticio> a2 = new ArrayList<Alimenticio>();
            a2 = BaseDadosAlimenticio.listar();
            for (Alimenticio a1 : a2){   
                this.printTextField("Codigo: " + a1.getCodigo());
                this.printTextField("\nNome: " + a1.getNome());
                this.printTextField("\nMarca: "+a1.getMarca());
                this.printTextField("\nPreço: R$" + a1.getPreco());
                this.printTextField("\nQuantidade: "+ a1.getQuantidade());
                this.printTextField("\nData de Validade: "+a1.getDataValidade());
                this.printTextField("\n---------\n");          
            }
        break; 
        
        case 1:
            ArrayList<Eletrodomesticos> e2 = new ArrayList<Eletrodomesticos>();
            e2 = BaseDadosEletrodomestico.listar();
            for (Eletrodomesticos e1 : e2){   
                this.printTextField("Codigo: " + e1.getCodigo());
                this.printTextField("\nNome: " + e1.getNome());
                this.printTextField("\nMarca: "+e1.getMarca());
                this.printTextField("\nPreço: R$" + e1.getPreco());
                this.printTextField("\nQuantidade: "+ e1.getQuantidade());
                this.printTextField("\nVoltagem: "+e1.getVoltagem());
                this.printTextField("\n---------\n");                  
            }
        break;
        
        case 2:
            ArrayList<Higiene> h2 = new ArrayList<Higiene>();
            h2 = BaseDadosHigiene.listar();
            for (Higiene h1 : h2){   
                this.printTextField("Codigo: " + h1.getCodigo());
                this.printTextField("\nNome: " + h1.getNome());
                this.printTextField("\nMarca: "+h1.getMarca());
                this.printTextField("\nPreço: R$" +h1.getPreco());
                this.printTextField("\nQuantidade: "+h1.getQuantidade());
                this.printTextField("\nData de Validade: "+h1.getDataValidade());
                this.printTextField("\n---------\n");                  
            }
            break;
            
        case 3:
            ArrayList<Moveis> m2 = new ArrayList<Moveis>();
            m2 = BaseDadosMoveis.listar();
            for (Moveis m1 : m2){   
                this.printTextField("Codigo: " + m1.getCodigo());
                this.printTextField("\nNome: " + m1.getNome());
                this.printTextField("\nMarca: "+m1.getMarca());
                this.printTextField("\nPreço: R$" + m1.getPreco());
                this.printTextField("\nQuantidade: "+ m1.getQuantidade());
                this.printTextField("\nMaterial: "+m1.getMaterial());
                this.printTextField("\n---------\n");                  
            }
            break;
        }
        }catch (Exception e){
            JOptionPane.showMessageDialog(this, "Erro "+ e);
        }
    }//GEN-LAST:event_jbListarMouseReleased

    private void jbListarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbListarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbListarActionPerformed

    
    public void printTextField(String text) {
    jTextArea1.append(text);
}
    
    

    
private javax.swing.JLabel Status;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton jbListar;
    private javax.swing.JButton jbvoltarL;
    // End of variables declaration//GEN-END:variables
}
